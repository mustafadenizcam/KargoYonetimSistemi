import java.util.*;

/*
 * Şehirler arası rota ağı.
 * Ağırlıklı, çift yönlü Adjacency List (Komşuluk Listesi).
 */
public class CityGraph {

    public static class Edge {
        public final City   destination;
        public final double distance; // km
        public final double cost;     // TL

        public Edge(City destination, double distance, double cost) {
            this.destination = destination;
            this.distance    = distance;
            this.cost        = cost;
        }

        @Override
        public String toString() {
            return String.format("[%s | %.0fkm | %.0f₺]",
                    destination.getCityName(), distance, cost);
        }
    }

    private final Map<String, City>       cities;
    private final Map<String, List<Edge>> adjacencyList;
    // Eklenen kenarları takip et — çift eklemeyi önlemek için
    private final Set<String>             addedEdges;

    public CityGraph() {
        cities        = new LinkedHashMap<>();
        adjacencyList = new LinkedHashMap<>();
        addedEdges    = new HashSet<>();
    }

    public void addCity(City city) {
        cities.put(city.getCityId(), city);
        adjacencyList.putIfAbsent(city.getCityId(), new ArrayList<>());
    }

    // ── Standart çift yönlü ekleme (tekrar engeli yok) ───────────────────
    public void addRoute(String a, String b, double dist, double cost) {
        City ca = cities.get(a), cb = cities.get(b);
        if (ca == null || cb == null) {
            System.out.println("[HATA] Şehir bulunamadı: " + a + " veya " + b); return;
        }
        adjacencyList.get(a).add(new Edge(cb, dist, cost));
        adjacencyList.get(b).add(new Edge(ca, dist, cost));
    }

    // ── Tekrar engelli ekleme (DataLoader kullanır) ───────────────────────
    public void addRouteOnce(String a, String b, double dist, double cost) {
        String key = a.compareTo(b) < 0 ? a + "-" + b : b + "-" + a;
        if (addedEdges.contains(key)) return;
        addedEdges.add(key);
        addRoute(a, b, dist, cost);
    }

    public List<Edge>       getNeighbors(String cityId)  { return adjacencyList.getOrDefault(cityId, Collections.emptyList()); }
    public City             getCity(String cityId)        { return cities.get(cityId); }
    public Collection<City> getAllCities()                { return cities.values(); }
    public boolean          containsCity(String cityId)  { return cities.containsKey(cityId); }

    public void printGraph() {
        System.out.println("\n--- Şehir Rota Ağı (Graf) ---");
        for (Map.Entry<String, List<Edge>> entry : adjacencyList.entrySet()) {
            City city = cities.get(entry.getKey());
            System.out.print(city.getCityName() + " -> ");
            entry.getValue().forEach(e -> System.out.print(e + "  "));
            System.out.println();
        }
    }
}
