=== KARGO YÖNETİM SİSTEMİ ===
Veri Yapıları & Algoritmalar Dersi Projesi

ÇALIŞTIRMA:
  1. Tüm .java dosyalarını IntelliJ IDEA'ya açın
  2. Main.java'yı çalıştırın (main metodu burada)
  3. paketler.txt ve sehirler.txt dosyaları 
     projenin KÖKÜNDE (java dosyalarıyla aynı klasörde) olmalı!

DOSYALAR:
  Package.java          - Paket veri modeli
  Box.java              - Kutu veri modeli  
  Cargo.java            - Kargo sevkiyat modeli (kullanımda!)
  City.java             - Şehir modeli
  PackageHashTable.java - Elle yazılmış Hash Table (HashMap kullanılmaz!)
  CargoQueueSystem.java - Queue + PriorityQueue yapıları
  CityGraph.java        - Graf (Adjacency List, çift yönlü)
  DijkstraAlgorithm.java- Dijkstra (DISTANCE + COST modları)
  PackingAlgorithm.java - First Fit / Best Fit / FFD algoritmaları
  DataLoader.java       - Dosya okuma/yazma (File I/O)
  Main.java             - Swing GUI (4 sekme)

VERİ DOSYALARI:
  sehirler.txt  - Şehir ve rota bilgileri (ID,Ad,KOMSU:km:tl formatı)
  paketler.txt  - Başlangıç paket verileri

YAPILAN DEĞİŞİKLİKLER:
  - PackageHashTable: HashMap yerine elle yazılmış array+chaining hash table
  - CargoQueueSystem: PriorityQueue öncelik kriteri açıklandı (ağırlık bazlı VIP)
  - CityGraph: addRouteOnce ile çift ekleme engeli
  - DataLoader: Rotalar artık sehirler.txt'den okunuyor (hard-coded değil!)
  - Cargo sınıfı: Rota sekmesinde kargo oluşturma ile entegre edildi
  - Paketleme: FF / BF / FFD hepsi arayüzde + karşılaştırma tablosu
  - Teslim Edildi: Hem paket hem kargo için durum güncellemesi eklendi
  - Arayüz: Tamamen yeniden tasarlandı (koyu tema, renkli sekmeler, istatistik kartları)
