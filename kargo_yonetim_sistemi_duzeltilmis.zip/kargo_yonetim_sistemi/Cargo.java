import java.util.ArrayList;
import java.util.List;

/*
 * Bir kargo sevkiyatını temsil eder.
 * Birden fazla kutu (Box) içerir.
 * Kargo oluşturulduktan sonra PackingAlgorithm ile kutuları doldurulur,
 * ardından sisteme kaydedilerek takip edilir.
 */
public class Cargo {
    private final String     cargoId;
    private final City       fromCity;
    private final City       toCity;
    private final List<Box>  boxes;
    private       String     status; // "Hazırlanıyor" | "Yolda" | "Teslim Edildi"
    private       String     routeDescription; // Dijkstra sonucu güzergah metni

    public Cargo(String cargoId, City fromCity, City toCity) {
        this.cargoId          = cargoId;
        this.fromCity         = fromCity;
        this.toCity           = toCity;
        this.boxes            = new ArrayList<>();
        this.status           = "Hazırlanıyor";
        this.routeDescription = "";
    }

    public void addBox(Box box)               { boxes.add(box); }

    public int getTotalPackageCount() {
        return boxes.stream().mapToInt(b -> b.getPackages().size()).sum();
    }

    public String  getCargoId()          { return cargoId; }
    public City    getFromCity()         { return fromCity; }
    public City    getToCity()           { return toCity; }
    public List<Box> getBoxes()          { return boxes; }
    public String  getStatus()           { return status; }
    public void    setStatus(String s)   { this.status = s; }
    public String  getRouteDescription() { return routeDescription; }
    public void    setRouteDescription(String r) { this.routeDescription = r; }

    @Override
    public String toString() {
        return String.format("Kargo[%s] %s → %s | Kutu: %d | Toplam Paket: %d | Durum: %s",
                cargoId, fromCity.getCityName(), toCity.getCityName(),
                boxes.size(), getTotalPackageCount(), status);
    }
}
