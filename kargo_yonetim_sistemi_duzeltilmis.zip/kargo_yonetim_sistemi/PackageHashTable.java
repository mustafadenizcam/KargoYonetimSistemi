/*
 * Elle yazılmış Hash Table implementasyonu.
 * Java'nın HashMap sınıfı KULLANILMAMAKTADIR.
 * Çakışmalar Separate Chaining (LinkedList) yöntemiyle çözülür.
 */
import java.util.ArrayList;
import java.util.List;

public class PackageHashTable {

    private static final int DEFAULT_CAPACITY = 16;
    private static final double LOAD_FACTOR    = 0.75;

    // Zincir düğümü
    private static class Node {
        String  key;
        Package value;
        Node    next;
        Node(String key, Package value) { this.key = key; this.value = value; }
    }

    private Node[] buckets;
    private int    size;

    @SuppressWarnings("unchecked")
    public PackageHashTable() {
        buckets = new Node[DEFAULT_CAPACITY];
        size    = 0;
    }

    // ── Hash fonksiyonu ────────────────────────────────────────────────────
    private int hash(String key) {
        int h = 0;
        for (char c : key.toCharArray()) h = 31 * h + c;
        return Math.abs(h) % buckets.length;
    }

    // ── Yeniden boyutlandırma ──────────────────────────────────────────────
    @SuppressWarnings("unchecked")
    private void resize() {
        Node[] old = buckets;
        buckets = new Node[old.length * 2];
        size    = 0;
        for (Node head : old)
            for (Node n = head; n != null; n = n.next)
                addPackage(n.value);         // yeni diziye yeniden ekle
    }

    // ── Paket ekle ─────────────────────────────────────────────────────────
    public void addPackage(Package pkg) {
        if ((double) size / buckets.length >= LOAD_FACTOR) resize();

        int idx  = hash(pkg.getId());
        Node cur = buckets[idx];

        // Aynı key varsa güncelle
        while (cur != null) {
            if (cur.key.equals(pkg.getId())) { cur.value = pkg; return; }
            cur = cur.next;
        }
        // Başa ekle (chaining)
        Node node = new Node(pkg.getId(), pkg);
        node.next  = buckets[idx];
        buckets[idx] = node;
        size++;
        System.out.println("[HASH] Paket eklendi: " + pkg.getId()
                + "  →  bucket[" + idx + "]");
    }

    // ── ID ile arama  O(1) ortalama ────────────────────────────────────────
    public Package searchById(String id) {
        int  idx = hash(id);
        Node cur = buckets[idx];
        while (cur != null) {
            if (cur.key.equals(id)) return cur.value;
            cur = cur.next;
        }
        return null;
    }

    // ── Paket sil ─────────────────────────────────────────────────────────
    public boolean removePackage(String id) {
        int  idx  = hash(id);
        Node cur  = buckets[idx];
        Node prev = null;
        while (cur != null) {
            if (cur.key.equals(id)) {
                if (prev == null) buckets[idx] = cur.next;
                else              prev.next    = cur.next;
                size--;
                System.out.println("[HASH] Paket silindi: " + id);
                return true;
            }
            prev = cur; cur = cur.next;
        }
        System.out.println("[HASH] Paket bulunamadı: " + id);
        return false;
    }

    public int size() { return size; }

    // ── Tüm paketleri liste olarak döndür ─────────────────────────────────
    public List<Package> getAllPackages() {
        List<Package> list = new ArrayList<>();
        for (Node head : buckets)
            for (Node n = head; n != null; n = n.next)
                list.add(n.value);
        return list;
    }

    public void printAll() {
        if (size == 0) { System.out.println("Sistemde paket yok."); return; }
        System.out.println("--- Tüm Paketler (" + size + " adet) ---");
        for (Package p : getAllPackages()) System.out.println(p);
    }
}
