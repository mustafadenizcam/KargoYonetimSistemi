import java.io.*;
import java.util.List;

/*
 * Dosya okuma / yazma işlemleri.
 *
 * sehirler.txt formatı (her satır):
 *   CITY_ID,Şehir Adı,KOMSU_ID:mesafe_km:maliyet_tl,...
 *
 * paketler.txt formatı (her satır):
 *   PKG_ID,Gönderici,Alıcı,ağırlık_kg,hacim_litre,isPriority
 */
public class DataLoader {

    // ── Şehirleri + rotaları dosyadan yükle ───────────────────────────────
    public static void loadCities(CityGraph graph) {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream("sehirler.txt"), "UTF-8"))) {

            String line;
            // 1. Geçiş: şehirleri ekle
            java.util.List<String> lines = new java.util.ArrayList<>();
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                lines.add(line.trim());
                String[] parts = line.split(",");
                if (parts.length >= 2)
                    graph.addCity(new City(parts[0].trim(), parts[1].trim()));
            }

            // 2. Geçiş: rotaları ekle (çift yönlü, addRoute tekrarı önler)
            for (String l : lines) {
                String[] parts = l.split(",");
                if (parts.length < 3) continue;
                String srcId = parts[0].trim();
                for (int i = 2; i < parts.length; i++) {
                    String[] edge = parts[i].split(":");
                    if (edge.length == 3) {
                        String  dstId = edge[0].trim();
                        double  dist  = Double.parseDouble(edge[1]);
                        double  cost  = Double.parseDouble(edge[2]);
                        graph.addRouteOnce(srcId, dstId, dist, cost);
                    }
                }
            }
            System.out.println("[VERİ] Şehirler ve rotalar dosyadan yüklendi.");
        } catch (IOException e) {
            System.out.println("[HATA] sehirler.txt okunamadı: " + e.getMessage());
            loadDefaultCities(graph);
        }
    }

    // ── Paketleri dosyadan yükle ──────────────────────────────────────────
    public static void loadPackages(PackageHashTable hashTable,
                                    CargoQueueSystem queueSystem,
                                    List<Package>    packageList) {
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream("paketler.txt"), "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] p = line.split(",");
                if (p.length == 6) {
                    Package pkg = new Package(
                            p[0].trim(), p[1].trim(), p[2].trim(),
                            Double.parseDouble(p[3].trim()),
                            Double.parseDouble(p[4].trim()),
                            Boolean.parseBoolean(p[5].trim()));
                    hashTable.addPackage(pkg);
                    queueSystem.enqueue(pkg);
                    packageList.add(pkg);
                }
            }
            System.out.println("[VERİ] Paketler dosyadan yüklendi.");
        } catch (IOException e) {
            System.out.println("[HATA] paketler.txt okunamadı: " + e.getMessage());
        }
    }

    // ── Paketleri dosyaya kaydet ──────────────────────────────────────────
    public static void savePackages(List<Package> packageList) {
        try (PrintWriter pw = new PrintWriter(
                new OutputStreamWriter(new FileOutputStream("paketler.txt"), "UTF-8"))) {
            for (Package p : packageList)
                pw.printf("%s,%s,%s,%.1f,%.1f,%b%n",
                        p.getId(), p.getSenderName(), p.getReceiverName(),
                        p.getWeight(), p.getVolume(), p.isPriority());
            System.out.println("[VERİ] Paketler dosyaya kaydedildi.");
        } catch (IOException e) {
            System.out.println("[HATA] paketler.txt yazılamadı: " + e.getMessage());
        }
    }

    // ── Fallback: dosya yoksa hard-coded verilerle devam et ───────────────
    private static void loadDefaultCities(CityGraph graph) {
        graph.addCity(new City("IST", "İstanbul"));
        graph.addCity(new City("ANK", "Ankara"));
        graph.addCity(new City("IZM", "İzmir"));
        graph.addCity(new City("BUR", "Bursa"));
        graph.addCity(new City("ANT", "Antalya"));
        graph.addCity(new City("KON", "Konya"));
        graph.addCity(new City("ESK", "Eskişehir"));
        graph.addRoute("IST", "ANK", 450, 850);
        graph.addRoute("IST", "BUR", 150, 280);
        graph.addRoute("IST", "IZM", 480, 920);
        graph.addRoute("ANK", "IZM", 590, 1100);
        graph.addRoute("IZM", "ANT", 430, 810);
        graph.addRoute("ANK", "KON", 260, 490);
        graph.addRoute("ANT", "KON", 380, 720);
        graph.addRoute("BUR", "ESK", 190, 360);
        graph.addRoute("KON", "ESK", 240, 450);
        graph.addRoute("ANK", "ESK", 230, 440);
        System.out.println("[VERİ] Varsayılan şehir verileri yüklendi.");
    }
}
