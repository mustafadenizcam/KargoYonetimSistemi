import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

public class Main extends JFrame {

    // ── Arka plan veri yapıları ───────────────────────────────────────────
    private static final PackageHashTable hashTable   = new PackageHashTable();
    private static final CargoQueueSystem queueSystem = new CargoQueueSystem();
    private static final CityGraph        graph       = new CityGraph();
    private static final List<Package>    allPackages = new ArrayList<>();
    private static final List<Cargo>      allCargos   = new ArrayList<>();
    private static DijkstraAlgorithm dijkstra;
    private static final PackingAlgorithm packer = new PackingAlgorithm(25.0, 15.0);
    private static int cargoCounter = 1;

    // ── Renkler ───────────────────────────────────────────────────────────
    private static final Color COL_DARK   = new Color(15,  28,  53);
    private static final Color COL_NAV    = new Color(26,  39,  68);
    private static final Color COL_ACCENT = new Color(234, 108,  10);
    private static final Color COL_ACCENT2= new Color(59, 130, 246);
    private static final Color COL_BG     = new Color(245, 246, 250);
    private static final Color COL_CARD   = Color.WHITE;
    private static final Color COL_TEXT   = new Color(30,  30,  40);
    private static final Color COL_MUTED  = new Color(120, 120, 140);
    private static final Color COL_BORDER = new Color(220, 220, 230);
    private static final Color COL_SUCCESS= new Color(21, 128, 61);
    private static final Color COL_WARN   = new Color(146, 64,  14);

    // ── UI referansları ───────────────────────────────────────────────────
    private DefaultTableModel paketTableModel;
    private DefaultTableModel cargoTableModel;
    private JTextArea         queueLogArea;
    private JTextArea         rotaSonucArea;
    private JTextArea         paketlemeSonucArea;
    private JLabel            statToplam, statVip, statNormal;
    private JPanel            vipQueuePanel, normalQueuePanel;

    // ── Kuyruk istatistik etiketleri ─────────────────────────────────────
    private JLabel lblVipCount, lblNormalCount;

    // ══════════════════════════════════════════════════════════════════════
    public Main() {
        sistemeVeriYukle();
        buildUI();
    }

    // ── Stil yardımcıları ─────────────────────────────────────────────────
    private JPanel card(LayoutManager lm) {
        JPanel p = new JPanel(lm);
        p.setBackground(COL_CARD);
        p.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(COL_BORDER, 1, true),
                new EmptyBorder(14, 16, 14, 16)));
        return p;
    }

    private JLabel sectionLabel(String text) {
        JLabel l = new JLabel(text.toUpperCase());
        l.setFont(new Font("SansSerif", Font.BOLD, 10));
        l.setForeground(COL_MUTED);
        return l;
    }

    private JButton accentBtn(String text) {
        JButton b = new JButton(text);
        b.setBackground(COL_ACCENT);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("SansSerif", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(new EmptyBorder(8, 18, 8, 18));
        return b;
    }

    private JButton secondaryBtn(String text) {
        JButton b = new JButton(text);
        b.setBackground(new Color(235, 236, 242));
        b.setForeground(COL_TEXT);
        b.setFont(new Font("SansSerif", Font.PLAIN, 13));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorder(new EmptyBorder(7, 16, 7, 16));
        return b;
    }

    private JTextField styledField() {
        JTextField tf = new JTextField();
        tf.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tf.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(COL_BORDER, 1, true),
                new EmptyBorder(5, 8, 5, 8)));
        return tf;
    }

    private JTable styledTable(DefaultTableModel model) {
        JTable t = new JTable(model) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        t.setFont(new Font("SansSerif", Font.PLAIN, 13));
        t.setRowHeight(26);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setSelectionBackground(new Color(234, 108, 10, 40));
        t.setSelectionForeground(COL_TEXT);
        t.setBackground(COL_CARD);
        t.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 11));
        t.getTableHeader().setBackground(COL_BG);
        t.getTableHeader().setForeground(COL_MUTED);
        t.getTableHeader().setBorder(BorderFactory.createMatteBorder(0,0,1,0,COL_BORDER));
        // Satır renklendirme
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable tbl, Object val,
                    boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(tbl,val,sel,foc,row,col);
                if (!sel) c.setBackground(row % 2 == 0 ? COL_CARD : new Color(248,249,252));
                setBorder(new EmptyBorder(0, 8, 0, 8));
                return c;
            }
        });
        return t;
    }

    private JScrollPane scrollOf(Component c) {
        JScrollPane sp = new JScrollPane(c);
        sp.setBorder(BorderFactory.createLineBorder(COL_BORDER));
        sp.getViewport().setBackground(COL_CARD);
        return sp;
    }

    // ── Üst başlık ────────────────────────────────────────────────────────
    private JPanel buildHeader() {
        JPanel h = new JPanel(new BorderLayout());
        h.setBackground(COL_DARK);
        h.setPreferredSize(new Dimension(0, 52));

        JLabel title = new JLabel("  📦  Kargo Yönetim Sistemi");
        title.setFont(new Font("SansSerif", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        h.add(title, BorderLayout.WEST);

        JLabel sub = new JLabel("Veri Yapıları & Algoritmalar Projesi   ");
        sub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        sub.setForeground(new Color(160, 170, 200));
        h.add(sub, BorderLayout.EAST);
        return h;
    }

    // ── Sekme çubuğu ─────────────────────────────────────────────────────
    private Color[] tabBg   = new Color[4];
    private JLabel[] tabLbl = new JLabel[4];

    private JPanel buildTabBar(JPanel content, CardLayout cl) {
        String[] tabs = {"📦  Paket İşlemleri","🔄  Kuyruk Yönetimi","🗺  Rota Hesaplama","📬  Paketleme"};
        JPanel bar = new JPanel(new GridLayout(1, tabs.length));
        bar.setBackground(COL_NAV);
        bar.setPreferredSize(new Dimension(0, 42));
        for (int i = 0; i < tabs.length; i++) {
            final int idx = i;
            JLabel l = new JLabel(tabs[i], SwingConstants.CENTER);
            l.setFont(new Font("SansSerif", Font.PLAIN, 13));
            l.setForeground(new Color(160,170,200));
            l.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            l.setOpaque(true);
            l.setBackground(COL_NAV);
            l.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { switchTab(idx, cl, content); }
            });
            tabLbl[i] = l;
            bar.add(l);
        }
        switchTab(0, cl, content);
        return bar;
    }

    private void switchTab(int idx, CardLayout cl, JPanel content) {
        String[] names = {"paket","kuyruk","rota","paketleme"};
        cl.show(content, names[idx]);
        for (int i = 0; i < tabLbl.length; i++) {
            boolean active = (i == idx);
            tabLbl[i].setForeground(active ? COL_ACCENT : new Color(160,170,200));
            tabLbl[i].setBorder(active
                    ? BorderFactory.createMatteBorder(0,0,2,0,COL_ACCENT)
                    : BorderFactory.createEmptyBorder());
        }
    }

    // ── Ana UI kurulumu ───────────────────────────────────────────────────
    private void buildUI() {
        setTitle("Kargo Yönetim Sistemi");
        setSize(1100, 680);
        setMinimumSize(new Dimension(900, 580));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(COL_BG);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(COL_BG);

        root.add(buildHeader(), BorderLayout.NORTH);

        CardLayout cl      = new CardLayout();
        JPanel     content = new JPanel(cl);
        content.setBackground(COL_BG);
        content.add(buildPaketTab(),     "paket");
        content.add(buildKuyrukTab(),    "kuyruk");
        content.add(buildRotaTab(),      "rota");
        content.add(buildPaketlemeTab(), "paketleme");

        JPanel tabBar = buildTabBar(content, cl);

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(COL_BG);
        center.add(tabBar,   BorderLayout.NORTH);
        center.add(content,  BorderLayout.CENTER);
        root.add(center, BorderLayout.CENTER);

        add(root);
    }

    // ══════════════════════════════════════════════════════════════════════
    // SEKME 1 — PAKET İŞLEMLERİ
    // ══════════════════════════════════════════════════════════════════════
    private JPanel buildPaketTab() {
        JPanel outer = new JPanel(new BorderLayout(10, 10));
        outer.setBackground(COL_BG);
        outer.setBorder(new EmptyBorder(12, 12, 12, 12));

        // Sol: form + sorgulama
        JPanel left = new JPanel(new BorderLayout(0, 10));
        left.setBackground(COL_BG);
        left.setPreferredSize(new Dimension(290, 0));

        // İstatistik kartları
        JPanel statRow = new JPanel(new GridLayout(1, 3, 8, 0));
        statRow.setBackground(COL_BG);
        statToplam = statCard(statRow, "Toplam", "0", COL_ACCENT);
        statVip    = statCard(statRow, "VIP",    "0", new Color(180, 60, 20));
        statNormal = statCard(statRow, "Normal", "0", COL_ACCENT2);

        // Form
        JPanel formCard = card(new GridBagLayout());
        formCard.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(COL_BORDER, 1, true),
                new EmptyBorder(12, 14, 12, 14)));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL; gc.insets = new Insets(4,2,4,2);

        JTextField fId   = styledField();
        JTextField fGon  = styledField();
        JTextField fAl   = styledField();
        JTextField fAg   = styledField();
        JTextField fHac  = styledField();
        JCheckBox  cbVip = new JCheckBox("VIP / Öncelikli Kargo");
        cbVip.setFont(new Font("SansSerif", Font.PLAIN, 13));
        cbVip.setBackground(COL_CARD);

        String[] labels = {"Paket ID:","Gönderici:","Alıcı:","Ağırlık (kg):","Hacim (L):"};
        JTextField[] fields = {fId, fGon, fAl, fAg, fHac};

        // Üst başlık
        gc.gridx=0; gc.gridy=0; gc.gridwidth=2;
        JLabel formTitle = sectionLabel("Yeni Kargo Girişi");
        formTitle.setBorder(new EmptyBorder(0,0,6,0));
        formCard.add(formTitle, gc);
        gc.gridwidth=1;

        for (int i = 0; i < labels.length; i++) {
            gc.gridx=0; gc.gridy=i+1; gc.weightx=0;
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(new Font("SansSerif", Font.PLAIN, 12));
            lbl.setForeground(COL_MUTED);
            formCard.add(lbl, gc);
            gc.gridx=1; gc.weightx=1;
            formCard.add(fields[i], gc);
        }
        gc.gridx=0; gc.gridy=6; gc.gridwidth=2; gc.weightx=1;
        formCard.add(cbVip, gc);

        JButton btnEkle = accentBtn("+ Sisteme Ekle");
        gc.gridy=7; gc.insets = new Insets(8,2,2,2);
        formCard.add(btnEkle, gc);

        // Sorgulama
        JPanel araCard = card(new BorderLayout(6, 6));
        araCard.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(COL_BORDER, 1, true),
                new EmptyBorder(10, 14, 10, 14)));
        JPanel araTop = new JPanel(new BorderLayout(6,0));
        araTop.setBackground(COL_CARD);
        araTop.add(sectionLabel("Paket Sorgula (Hash Table)"), BorderLayout.NORTH);
        JTextField fAra = styledField();
        fAra.setToolTipText("Paket ID girin");
        JButton btnAra = secondaryBtn("Ara");
        araTop.add(fAra, BorderLayout.CENTER);
        araTop.add(btnAra, BorderLayout.EAST);
        JTextArea araResult = new JTextArea(3, 1);
        araResult.setEditable(false);
        araResult.setFont(new Font("Monospaced", Font.PLAIN, 12));
        araResult.setBackground(COL_BG);
        araResult.setBorder(new EmptyBorder(6,0,0,0));
        araCard.add(araTop, BorderLayout.NORTH);
        araCard.add(araResult, BorderLayout.CENTER);

        left.add(statRow,  BorderLayout.NORTH);
        JPanel formWrap = new JPanel(new BorderLayout(0,8));
        formWrap.setBackground(COL_BG);
        formWrap.add(formCard, BorderLayout.CENTER);
        formWrap.add(araCard,  BorderLayout.SOUTH);
        left.add(formWrap, BorderLayout.CENTER);

        // Sağ: tablo
        JPanel rightCard = card(new BorderLayout(0, 8));
        JLabel tblTitle = sectionLabel("Kayıtlı Paketler — Hash Table");
        tblTitle.setBorder(new EmptyBorder(0,0,6,0));
        rightCard.add(tblTitle, BorderLayout.NORTH);

        String[] cols = {"ID","Gönderici","Alıcı","Ağırlık (kg)","Hacim (L)","Tür","Durum"};
        paketTableModel = new DefaultTableModel(cols, 0);
        JTable table = styledTable(paketTableModel);
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        rightCard.add(scrollOf(table), BorderLayout.CENTER);

        // Buton satırı altına
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        btnRow.setBackground(COL_CARD);
        JButton btnTeslim = secondaryBtn("✓ Teslim Edildi");
        JButton btnSil    = secondaryBtn("✗ Sil");
        btnSil.setForeground(new Color(180, 30, 30));
        JButton btnKaydet = secondaryBtn("💾 Dosyaya Kaydet");
        btnRow.add(btnTeslim); btnRow.add(btnSil); btnRow.add(btnKaydet);
        rightCard.add(btnRow, BorderLayout.SOUTH);

        outer.add(left,      BorderLayout.WEST);
        outer.add(rightCard, BorderLayout.CENTER);

        // Tüm paketleri yükle
        allPackages.forEach(this::addRowToTable);
        updateStats();

        // ── Action listeners ──
        btnEkle.addActionListener(e -> {
            try {
                String id  = fId.getText().trim();
                String gon = fGon.getText().trim();
                String al  = fAl.getText().trim();
                if (id.isEmpty() || gon.isEmpty() || al.isEmpty()) throw new Exception("Boş alan");
                double ag  = Double.parseDouble(fAg.getText().trim());
                double hac = Double.parseDouble(fHac.getText().trim());
                if (hashTable.searchById(id) != null) {
                    showMsg("Bu ID zaten kayıtlı: " + id, false); return;
                }
                Package pkg = new Package(id, gon, al, ag, hac, cbVip.isSelected());
                hashTable.addPackage(pkg);
                queueSystem.enqueue(pkg);
                allPackages.add(pkg);
                addRowToTable(pkg);
                updateStats();
                refreshQueues();
                fId.setText(""); fGon.setText(""); fAl.setText("");
                fAg.setText(""); fHac.setText(""); cbVip.setSelected(false);
                showMsg("Paket eklendi: " + id, true);
            } catch (NumberFormatException ex) {
                showMsg("Ağırlık ve hacim sayı olmalı!", false);
            } catch (Exception ex) {
                showMsg("Tüm alanları doldurun.", false);
            }
        });

        btnAra.addActionListener(e -> {
            String id = fAra.getText().trim();
            if (id.isEmpty()) return;
            Package p = hashTable.searchById(id);
            if (p != null) {
                araResult.setText("✓ BULUNDU (O(1))\n" +
                        "Durum   : " + p.getStatus() + "\n" +
                        "Gönderci: " + p.getSenderName() + "\n" +
                        "Alıcı   : " + p.getReceiverName() + "\n" +
                        "Ağırlık : " + p.getWeight() + " kg\n" +
                        "Hacim   : " + p.getVolume() + " L");
                araResult.setForeground(COL_SUCCESS);
            } else {
                araResult.setText("✗ " + id + " bulunamadı.");
                araResult.setForeground(new Color(180, 30, 30));
            }
        });
        fAra.addActionListener(btnAra.getActionListeners()[0]);

        btnTeslim.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showMsg("Önce bir satır seçin.", false); return; }
            String id = (String) paketTableModel.getValueAt(row, 0);
            Package p = hashTable.searchById(id);
            if (p != null) {
                p.setStatus("Teslim Edildi");
                paketTableModel.setValueAt("Teslim Edildi", row, 6);
            }
        });

        btnSil.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { showMsg("Önce bir satır seçin.", false); return; }
            String id = (String) paketTableModel.getValueAt(row, 0);
            hashTable.removePackage(id);
            allPackages.removeIf(p -> p.getId().equals(id));
            paketTableModel.removeRow(row);
            updateStats();
        });

        btnKaydet.addActionListener(e -> {
            DataLoader.savePackages(allPackages);
            showMsg("Paketler dosyaya kaydedildi.", true);
        });

        return outer;
    }

    private JLabel statCard(JPanel parent, String label, String val, Color color) {
        JPanel c = new JPanel(new BorderLayout());
        c.setBackground(COL_CARD);
        c.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(COL_BORDER,1,true), new EmptyBorder(8,10,8,10)));
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lbl.setForeground(COL_MUTED);
        JLabel num = new JLabel(val);
        num.setFont(new Font("SansSerif", Font.BOLD, 22));
        num.setForeground(color);
        c.add(lbl, BorderLayout.NORTH);
        c.add(num, BorderLayout.CENTER);
        parent.add(c);
        return num;
    }

    private void addRowToTable(Package p) {
        paketTableModel.addRow(new Object[]{
                p.getId(), p.getSenderName(), p.getReceiverName(),
                p.getWeight() + " kg", p.getVolume() + " L",
                p.isPriority() ? "⚡ VIP" : "Normal",
                p.getStatus()
        });
    }

    private void updateStats() {
        int total = allPackages.size();
        long vip  = allPackages.stream().filter(Package::isPriority).count();
        statToplam.setText(String.valueOf(total));
        statVip.setText(String.valueOf(vip));
        statNormal.setText(String.valueOf(total - vip));
    }

    // ══════════════════════════════════════════════════════════════════════
    // SEKME 2 — KUYRUK YÖNETİMİ
    // ══════════════════════════════════════════════════════════════════════
    private JPanel buildKuyrukTab() {
        JPanel outer = new JPanel(new BorderLayout(10, 10));
        outer.setBackground(COL_BG);
        outer.setBorder(new EmptyBorder(12, 12, 12, 12));

        // Sol: kuyruk listeleri
        JPanel left = new JPanel(new BorderLayout(0, 10));
        left.setBackground(COL_BG);
        left.setPreferredSize(new Dimension(320, 0));

        JPanel vipCard = card(new BorderLayout(0, 6));
        lblVipCount = sectionLabel("VIP KUYRUK (0)");
        vipCard.add(lblVipCount, BorderLayout.NORTH);
        vipQueuePanel = new JPanel();
        vipQueuePanel.setLayout(new BoxLayout(vipQueuePanel, BoxLayout.Y_AXIS));
        vipQueuePanel.setBackground(COL_CARD);
        vipCard.add(scrollOf(vipQueuePanel), BorderLayout.CENTER);

        JPanel normalCard = card(new BorderLayout(0, 6));
        lblNormalCount = sectionLabel("NORMAL KUYRUK (0)");
        normalCard.add(lblNormalCount, BorderLayout.NORTH);
        normalQueuePanel = new JPanel();
        normalQueuePanel.setLayout(new BoxLayout(normalQueuePanel, BoxLayout.Y_AXIS));
        normalQueuePanel.setBackground(COL_CARD);
        normalCard.add(scrollOf(normalQueuePanel), BorderLayout.CENTER);

        left.add(vipCard,    BorderLayout.CENTER);
        left.add(normalCard, BorderLayout.SOUTH);
        vipCard.setPreferredSize(new Dimension(0, 280));
        normalCard.setPreferredSize(new Dimension(0, 200));

        // Sağ: log + buton
        JPanel right = new JPanel(new BorderLayout(0, 10));
        right.setBackground(COL_BG);

        JButton btnIsle = accentBtn("▶  Sıradaki Paketi İşle");
        btnIsle.setPreferredSize(new Dimension(0, 44));

        JPanel logCard = card(new BorderLayout(0, 6));
        logCard.add(sectionLabel("İşlem Geçmişi / Sistem Logu"), BorderLayout.NORTH);
        queueLogArea = new JTextArea();
        queueLogArea.setEditable(false);
        queueLogArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        queueLogArea.setBackground(new Color(15, 28, 53));
        queueLogArea.setForeground(new Color(163, 230, 53));
        queueLogArea.setBorder(new EmptyBorder(8, 10, 8, 10));
        logCard.add(scrollOf(queueLogArea), BorderLayout.CENTER);

        right.add(btnIsle, BorderLayout.NORTH);
        right.add(logCard, BorderLayout.CENTER);

        outer.add(left,  BorderLayout.WEST);
        outer.add(right, BorderLayout.CENTER);

        appendLog("[SİSTEM] Kargo yönetim sistemi başlatıldı.", "ok");
        appendLog("[VERİ]   " + allPackages.size() + " paket yüklendi → Hash Table'a eklendi.", "ok");
        appendLog("[KUYRUK] Queue ve PriorityQueue yapıları hazır.", "info");
        refreshQueues();

        btnIsle.addActionListener(e -> {
            if (queueSystem.isEmpty()) {
                appendLog("[KUYRUK] İşlenecek paket kalmadı.", "warn"); return;
            }
            Package p = queueSystem.processNext();
            if (p != null) {
                p.setStatus("Yolda");
                updateTableStatus(p.getId(), "Yolda");
                appendLog("[İŞLEM] " + p.getId() + " işlendi → Durum: Yolda"
                        + (p.isPriority() ? "  (VIP öncelik)" : ""), p.isPriority() ? "vip" : "ok");
                refreshQueues();
            }
        });

        return outer;
    }

    private void refreshQueues() {
        // VIP
        vipQueuePanel.removeAll();
        List<Package> vipList = new ArrayList<>(queueSystem.getPriorityQueue());
        vipList.sort(Comparator.comparingDouble(Package::getWeight).reversed());
        for (int i = 0; i < vipList.size(); i++)
            vipQueuePanel.add(queueRow(i + 1, vipList.get(i), true));
        if (vipList.isEmpty()) vipQueuePanel.add(emptyLabel("Kuyruk boş"));
        lblVipCount.setText("VIP KUYRUK (" + vipList.size() + ")");

        // Normal
        normalQueuePanel.removeAll();
        List<Package> normalList = new ArrayList<>(queueSystem.getNormalQueue());
        for (int i = 0; i < normalList.size(); i++)
            normalQueuePanel.add(queueRow(i + 1, normalList.get(i), false));
        if (normalList.isEmpty()) normalQueuePanel.add(emptyLabel("Kuyruk boş"));
        lblNormalCount.setText("NORMAL KUYRUK (" + normalList.size() + ")");

        vipQueuePanel.revalidate(); vipQueuePanel.repaint();
        normalQueuePanel.revalidate(); normalQueuePanel.repaint();
    }

    private JPanel queueRow(int rank, Package p, boolean isVip) {
        JPanel row = new JPanel(new BorderLayout(8, 0));
        row.setBackground(isVip ? new Color(255, 247, 237) : new Color(248, 249, 252));
        row.setBorder(BorderFactory.createCompoundBorder(
                new MatteBorder(0, 0, 1, 0, COL_BORDER),
                new EmptyBorder(6, 8, 6, 8)));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));

        JLabel rankLbl = new JLabel(String.valueOf(rank));
        rankLbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        rankLbl.setForeground(isVip ? COL_ACCENT : COL_MUTED);
        rankLbl.setPreferredSize(new Dimension(22, 0));

        JPanel info = new JPanel(new GridLayout(2, 1));
        info.setOpaque(false);
        JLabel idLbl   = new JLabel(p.getId());
        idLbl.setFont(new Font("Monospaced", Font.BOLD, 12));
        JLabel metaLbl = new JLabel(p.getWeight() + " kg  ·  " + p.getSenderName() + " → " + p.getReceiverName());
        metaLbl.setFont(new Font("SansSerif", Font.PLAIN, 11));
        metaLbl.setForeground(COL_MUTED);
        info.add(idLbl); info.add(metaLbl);

        row.add(rankLbl, BorderLayout.WEST);
        row.add(info, BorderLayout.CENTER);
        if (isVip) {
            JLabel badge = new JLabel("⚡VIP");
            badge.setFont(new Font("SansSerif", Font.BOLD, 10));
            badge.setForeground(COL_WARN);
            row.add(badge, BorderLayout.EAST);
        }
        return row;
    }

    private JLabel emptyLabel(String txt) {
        JLabel l = new JLabel(txt, SwingConstants.CENTER);
        l.setFont(new Font("SansSerif", Font.ITALIC, 12));
        l.setForeground(COL_MUTED);
        l.setBorder(new EmptyBorder(10, 0, 10, 0));
        return l;
    }

    private void appendLog(String msg, String type) {
        if (queueLogArea == null) return;
        Color c;
        if      ("ok".equals(type))   c = new Color(74, 222, 128);
        else if ("vip".equals(type))  c = COL_ACCENT;
        else if ("warn".equals(type)) c = new Color(251, 191, 36);
        else                          c = new Color(147, 197, 253);
        queueLogArea.append(msg + "\n");
        queueLogArea.setCaretPosition(queueLogArea.getDocument().getLength());
    }

    private void updateTableStatus(String id, String status) {
        for (int i = 0; i < paketTableModel.getRowCount(); i++) {
            if (paketTableModel.getValueAt(i, 0).equals(id)) {
                paketTableModel.setValueAt(status, i, 6); break;
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    // SEKME 3 — ROTA HESAPLAMA
    // ══════════════════════════════════════════════════════════════════════
    private JPanel buildRotaTab() {
        JPanel outer = new JPanel(new BorderLayout(10, 10));
        outer.setBackground(COL_BG);
        outer.setBorder(new EmptyBorder(12, 12, 12, 12));

        // Sol: şehir tablosu + graf
        JPanel left = new JPanel(new BorderLayout(0, 10));
        left.setBackground(COL_BG);
        left.setPreferredSize(new Dimension(280, 0));

        JPanel cityCard = card(new BorderLayout(0, 6));
        cityCard.add(sectionLabel("Şehirler (Tablodan seçin)"), BorderLayout.NORTH);
        DefaultTableModel cityModel = new DefaultTableModel(
                new String[]{"Kod","Şehir"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        graph.getAllCities().forEach(c -> cityModel.addRow(new Object[]{c.getCityId(), c.getCityName()}));
        JTable cityTable = styledTable(cityModel);
        cityTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        cityCard.add(scrollOf(cityTable), BorderLayout.CENTER);

        // Graf görünümü
        JPanel grafCard = card(new BorderLayout(0,4));
        grafCard.add(sectionLabel("Komşuluk Listesi (Graf)"), BorderLayout.NORTH);
        JTextArea grafArea = new JTextArea();
        grafArea.setEditable(false);
        grafArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        grafArea.setBackground(COL_BG);
        StringBuilder sb = new StringBuilder();
        for (City c : graph.getAllCities()) {
            sb.append(c.getCityName()).append(" →\n");
            graph.getNeighbors(c.getCityId()).forEach(e ->
                    sb.append("  ").append(e.destination.getCityName())
                      .append("  ").append((int)e.distance).append("km / ")
                      .append((int)e.cost).append("₺\n"));
        }
        grafArea.setText(sb.toString());
        grafCard.add(scrollOf(grafArea), BorderLayout.CENTER);

        left.add(cityCard, BorderLayout.CENTER);
        left.add(grafCard, BorderLayout.SOUTH);
        grafCard.setPreferredSize(new Dimension(0, 220));

        // Sağ: seçim + sonuç
        JPanel right = new JPanel(new BorderLayout(0, 10));
        right.setBackground(COL_BG);

        JPanel selCard = card(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL; gc.insets = new Insets(4,4,4,4);

        JTextField fSrc = styledField(); fSrc.setEditable(false);
        JTextField fDst = styledField(); fDst.setEditable(false);
        JButton btnSrc = secondaryBtn("Çıkış Şehri Yap");
        JButton btnDst = secondaryBtn("Varış Şehri Yap");
        JButton btnDist = accentBtn("📏 Mesafe Odaklı");
        JButton btnCost = secondaryBtn("💰 Maliyet Odaklı");

        // Kargo oluştur butonu
        JButton btnCargo = secondaryBtn("📬 Bu Rotaya Kargo Oluştur");

        gc.gridx=0; gc.gridy=0; gc.gridwidth=2; selCard.add(sectionLabel("Rota Belirleme"), gc);
        gc.gridwidth=1;
        gc.gridx=0; gc.gridy=1; gc.weightx=0; selCard.add(btnSrc, gc);
        gc.gridx=1; gc.weightx=1; selCard.add(fSrc, gc);
        gc.gridx=0; gc.gridy=2; gc.weightx=0; selCard.add(btnDst, gc);
        gc.gridx=1; gc.weightx=1; selCard.add(fDst, gc);
        gc.gridx=0; gc.gridy=3; gc.gridwidth=1; selCard.add(btnDist, gc);
        gc.gridx=1; selCard.add(btnCost, gc);
        gc.gridx=0; gc.gridy=4; gc.gridwidth=2; selCard.add(btnCargo, gc);

        JPanel sonucCard = card(new BorderLayout(0, 6));
        sonucCard.add(sectionLabel("Dijkstra Algoritması — Sonuç"), BorderLayout.NORTH);
        rotaSonucArea = new JTextArea();
        rotaSonucArea.setEditable(false);
        rotaSonucArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        rotaSonucArea.setBackground(COL_BG);
        rotaSonucArea.setBorder(new EmptyBorder(6, 6, 6, 6));
        sonucCard.add(scrollOf(rotaSonucArea), BorderLayout.CENTER);

        // Kargo tablosu
        JPanel cargoCard = card(new BorderLayout(0,4));
        cargoCard.add(sectionLabel("Oluşturulan Kargolar"), BorderLayout.NORTH);
        String[] cCols = {"Kargo ID","Çıkış","Varış","Kutu","Paket","Durum"};
        cargoTableModel = new DefaultTableModel(cCols, 0);
        JTable cargoTblMain = styledTable(cargoTableModel);
        cargoCard.add(scrollOf(cargoTblMain), BorderLayout.CENTER);

        // Durum butonları
        JPanel cargoBtn = new JPanel(new FlowLayout(FlowLayout.LEFT,6,0));
        cargoBtn.setBackground(COL_CARD);
        JButton btnYolda  = secondaryBtn("→ Yolda Yap");
        JButton btnTeslim = secondaryBtn("✓ Teslim Edildi");
        cargoBtn.add(btnYolda); cargoBtn.add(btnTeslim);
        cargoCard.add(cargoBtn, BorderLayout.SOUTH);

        right.add(selCard,   BorderLayout.NORTH);
        right.add(sonucCard, BorderLayout.CENTER);
        right.add(cargoCard, BorderLayout.SOUTH);
        cargoCard.setPreferredSize(new Dimension(0, 200));

        outer.add(left,  BorderLayout.WEST);
        outer.add(right, BorderLayout.CENTER);

        // ── Listeners ──
        btnSrc.addActionListener(e -> {
            int r = cityTable.getSelectedRow();
            if (r < 0) { showMsg("Tablodan şehir seçin.", false); return; }
            fSrc.setText((String) cityModel.getValueAt(r, 0));
        });
        btnDst.addActionListener(e -> {
            int r = cityTable.getSelectedRow();
            if (r < 0) { showMsg("Tablodan şehir seçin.", false); return; }
            fDst.setText((String) cityModel.getValueAt(r, 0));
        });

        ActionListener calcListener = e -> {
            String src = fSrc.getText().trim(), dst = fDst.getText().trim();
            if (src.isEmpty() || dst.isEmpty()) {
                rotaSonucArea.setText("Lütfen çıkış ve varış şehirlerini seçin."); return;
            }
            if (src.equals(dst)) {
                rotaSonucArea.setText("Çıkış ve varış şehri aynı olamaz."); return;
            }
            boolean isMesafe = e.getSource() == btnDist;
            DijkstraAlgorithm.Mode mode = isMesafe
                    ? DijkstraAlgorithm.Mode.DISTANCE
                    : DijkstraAlgorithm.Mode.COST;
            DijkstraAlgorithm.RouteResult r = dijkstra.findShortestPath(src, dst, mode);
            StringBuilder res = new StringBuilder();
            res.append(isMesafe ? "── MESAFE OPTİMİZASYONU (Dijkstra) ──\n\n"
                                : "── MALİYET OPTİMİZASYONU (Dijkstra) ──\n\n");
            if (r.found) {
                res.append("Güzergah : ").append(String.join(" → ", r.path)).append("\n");
                res.append("Mesafe   : ").append(r.totalDistance).append(" km\n");
                res.append("Maliyet  : ").append(String.format("%.0f ₺", r.totalCost)).append("\n");
                res.append("Durak    : ").append(r.path.size()).append(" şehir\n");
            } else {
                res.append("Rota bulunamadı — iki şehir arasında bağlantı yok.");
            }
            rotaSonucArea.setText(res.toString());
        };
        btnDist.addActionListener(calcListener);
        btnCost.addActionListener(calcListener);

        btnCargo.addActionListener(e -> {
            String src = fSrc.getText().trim(), dst = fDst.getText().trim();
            if (src.isEmpty() || dst.isEmpty()) { showMsg("Önce rota hesaplayın.", false); return; }
            City cSrc = graph.getCity(src), cDst = graph.getCity(dst);
            if (cSrc == null || cDst == null) { showMsg("Geçersiz şehir.", false); return; }
            String cargoId = "CRG-" + String.format("%03d", cargoCounter++);
            Cargo cargo = new Cargo(cargoId, cSrc, cDst);
            cargo.setStatus("Hazırlanıyor");
            // Paketsiz de olsa kargo kaydı oluştur
            allCargos.add(cargo);
            cargoTableModel.addRow(new Object[]{
                    cargo.getCargoId(), cSrc.getCityName(), cDst.getCityName(),
                    0, 0, cargo.getStatus()
            });
            showMsg("Kargo oluşturuldu: " + cargoId, true);
            appendLog("[KARGO] " + cargoId + " oluşturuldu: " + cSrc.getCityName() + " → " + cDst.getCityName(), "info");
        });

        // cargoTblMain already defined above
        // Durum güncelleme
        btnYolda.addActionListener(e -> updateCargoStatus(cargoTblMain, "Yolda"));
        btnTeslim.addActionListener(e -> updateCargoStatus(cargoTblMain, "Teslim Edildi"));

        return outer;
    }

    private void updateCargoStatus(JTable tbl, String status) {
        int row = tbl.getSelectedRow();
        if (row < 0) { showMsg("Tablodan kargo seçin.", false); return; }
        cargoTableModel.setValueAt(status, row, 5);
        String id = (String) cargoTableModel.getValueAt(row, 0);
        allCargos.stream().filter(c -> c.getCargoId().equals(id)).findFirst()
                .ifPresent(c -> c.setStatus(status));
    }

    // ══════════════════════════════════════════════════════════════════════
    // SEKME 4 — PAKETLEME OPTİMİZASYONU
    // ══════════════════════════════════════════════════════════════════════
    private JPanel buildPaketlemeTab() {
        JPanel outer = new JPanel(new BorderLayout(10, 10));
        outer.setBackground(COL_BG);
        outer.setBorder(new EmptyBorder(12, 12, 12, 12));

        // Sol: ayarlar
        JPanel left = new JPanel(new BorderLayout(0, 10));
        left.setBackground(COL_BG);
        left.setPreferredSize(new Dimension(240, 0));

        JPanel cfgCard = card(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL; gc.insets = new Insets(5,4,5,4); gc.weightx=1;

        JTextField fVol = styledField(); fVol.setText("25");
        JTextField fWt  = styledField(); fWt.setText("15");

        gc.gridx=0; gc.gridy=0; gc.gridwidth=2; cfgCard.add(sectionLabel("Kutu Ayarları"), gc);
        gc.gridwidth=1;
        gc.gridx=0; gc.gridy=1; gc.weightx=0; cfgCard.add(new JLabel("Maks. Hacim (L)"), gc);
        gc.gridx=1; gc.weightx=1; cfgCard.add(fVol, gc);
        gc.gridx=0; gc.gridy=2; gc.weightx=0; cfgCard.add(new JLabel("Maks. Ağırlık (kg)"), gc);
        gc.gridx=1; gc.weightx=1; cfgCard.add(fWt, gc);

        gc.gridx=0; gc.gridy=3; gc.gridwidth=2;
        cfgCard.add(new JSeparator(), gc);
        cfgCard.add(sectionLabel("Algoritma"), gc);

        JButton btnFF  = secondaryBtn("First Fit");
        JButton btnBF  = secondaryBtn("Best Fit");
        JButton btnFFD = accentBtn("First Fit Decreasing (FFD)");
        JButton btnAll = secondaryBtn("📊 Hepsini Karşılaştır");

        gc.gridy=4; cfgCard.add(btnFF, gc);
        gc.gridy=5; cfgCard.add(btnBF, gc);
        gc.gridy=6; cfgCard.add(btnFFD, gc);
        gc.gridy=7; cfgCard.add(new JSeparator(), gc);
        gc.gridy=8; cfgCard.add(btnAll, gc);

        left.add(cfgCard, BorderLayout.NORTH);

        // Sağ: sonuç
        JPanel rightCard = card(new BorderLayout(0, 6));
        rightCard.add(sectionLabel("Paketleme Sonucu"), BorderLayout.NORTH);
        paketlemeSonucArea = new JTextArea();
        paketlemeSonucArea.setEditable(false);
        paketlemeSonucArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        paketlemeSonucArea.setBackground(COL_BG);
        paketlemeSonucArea.setBorder(new EmptyBorder(6,6,6,6));
        rightCard.add(scrollOf(paketlemeSonucArea), BorderLayout.CENTER);

        outer.add(left, BorderLayout.WEST);
        outer.add(rightCard, BorderLayout.CENTER);

        // ── Listeners ──
        ActionListener algoListener = e -> {
            if (allPackages.isEmpty()) { paketlemeSonucArea.setText("Sistemde paket yok."); return; }
            double maxV, maxW;
            try {
                maxV = Double.parseDouble(fVol.getText().trim());
                maxW = Double.parseDouble(fWt.getText().trim());
            } catch (NumberFormatException ex) { showMsg("Hacim ve ağırlık sayı olmalı.", false); return; }

            PackingAlgorithm pa = new PackingAlgorithm(maxV, maxW);
            List<Package> pkgs  = new ArrayList<>(allPackages);

            if (e.getSource() == btnAll) {
                PackingAlgorithm.PackingResult ff  = pa.firstFit(new ArrayList<>(pkgs));
                PackingAlgorithm.PackingResult bf  = pa.bestFit(new ArrayList<>(pkgs));
                PackingAlgorithm.PackingResult ffd = pa.firstFitDecreasing(new ArrayList<>(pkgs));
                StringBuilder sb = new StringBuilder();
                sb.append("═══════════════════════════════════════\n");
                sb.append("  ALGORİTMA KARŞILAŞTIRMASI\n");
                sb.append("═══════════════════════════════════════\n");
                sb.append(String.format("  Paket sayısı    : %d%n", pkgs.size()));
                sb.append(String.format("  Kutu kapasitesi : %.0fL / %.0fkg%n%n", maxV, maxW));
                sb.append(String.format("  %-22s | Kutu | Doluluk%n","Algoritma"));
                sb.append("  ──────────────────────────────────\n");
                sb.append(String.format("  %-22s |  %2d  |  %.1f%%%n","First Fit",ff.boxes.size(),ff.averageUtilizationVolume()));
                sb.append(String.format("  %-22s |  %2d  |  %.1f%%%n","Best Fit",bf.boxes.size(),bf.averageUtilizationVolume()));
                sb.append(String.format("  %-22s |  %2d  |  %.1f%%%n","First Fit Decreasing",ffd.boxes.size(),ffd.averageUtilizationVolume()));
                sb.append("\n  ★ Önerilen: First Fit Decreasing (FFD)\n");
                sb.append("    Az kutu, yüksek doluluk oranı.\n");
                paketlemeSonucArea.setText(sb.toString());
                return;
            }

            PackingAlgorithm.PackingResult sonuc;
            if      (e.getSource() == btnFF)  sonuc = pa.firstFit(pkgs);
            else if (e.getSource() == btnBF)  sonuc = pa.bestFit(pkgs);
            else                              sonuc = pa.firstFitDecreasing(pkgs);

            StringBuilder sb = new StringBuilder();
            sb.append("═══════════════════════════════════════\n");
            sb.append("  ").append(sonuc.algorithmName).append("\n");
            sb.append("═══════════════════════════════════════\n");
            sb.append(String.format("  Toplam Paket    : %d%n", sonuc.packageCount));
            sb.append(String.format("  Kullanılan Kutu : %d%n", sonuc.boxes.size()));
            sb.append(String.format("  Ort. Doluluk    : %.1f%%%n%n", sonuc.averageUtilizationVolume()));
            for (Box box : sonuc.boxes) {
                sb.append("┌─ ").append(box.getBoxId()).append("\n");
                sb.append(String.format("│  Hacim  : %.1f / %.0f L  (%.0f%%)%n",
                        box.getUsedVolume(), box.getMaxVolume(),
                        box.getUsedVolume()/box.getMaxVolume()*100));
                sb.append(String.format("│  Ağırlık: %.1f / %.0f kg%n",
                        box.getUsedWeight(), box.getMaxWeight()));
                sb.append("│  Paketler:\n");
                box.getPackages().forEach(p ->
                        sb.append("│    └─ ").append(p.getId()).append("\n"));
                sb.append("└─────────────────────────────\n\n");
            }
            paketlemeSonucArea.setText(sb.toString());
            paketlemeSonucArea.setCaretPosition(0);
        };

        btnFF.addActionListener(algoListener);
        btnBF.addActionListener(algoListener);
        btnFFD.addActionListener(algoListener);
        btnAll.addActionListener(algoListener);

        return outer;
    }

    // ── Yardımcı ─────────────────────────────────────────────────────────
    private void showMsg(String msg, boolean success) {
        JOptionPane.showMessageDialog(this, msg,
                success ? "Bilgi" : "Hata",
                success ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE);
    }

    // ── Veri yükleme ─────────────────────────────────────────────────────
    private static void sistemeVeriYukle() {
        DataLoader.loadCities(graph);
        DataLoader.loadPackages(hashTable, queueSystem, allPackages);
        dijkstra = new DijkstraAlgorithm(graph);
    }

    // ── Main ─────────────────────────────────────────────────────────────
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {}

        SwingUtilities.invokeLater(() -> {
            Main gui = new Main();
            gui.setVisible(true);
        });
    }
}
