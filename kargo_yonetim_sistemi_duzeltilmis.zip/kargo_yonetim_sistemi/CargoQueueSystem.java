/*
 * Normal kargolar için Queue (FIFO),
 * VIP/öncelikli kargolar için MinHeap tabanlı PriorityQueue.
 *
 * PriorityQueue öncelik kriteri:
 *   → isPriority=true olan paketler her zaman önce işlenir.
 *   → Aynı öncelik seviyesinde ağırlığı fazla olan öne geçer.
 */
import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class CargoQueueSystem {

    // Normal kargo kuyruğu (FIFO)
    private final Queue<Package> normalQueue;

    // VIP kargo kuyruğu: önce isPriority=true, eşitlikte daha ağır paket önce
    private final PriorityQueue<Package> priorityQueue;

    public CargoQueueSystem() {
        normalQueue   = new LinkedList<>();
        priorityQueue = new PriorityQueue<>(
            Comparator.comparingDouble(Package::getWeight).reversed()
        );
    }

    // Paketi uygun kuyruğa ekle
    public void enqueue(Package pkg) {
        if (pkg.isPriority()) {
            priorityQueue.add(pkg);
            System.out.println("[KUYRUK] VIP kuyruğuna eklendi: " + pkg.getId()
                    + "  (ağırlık=" + pkg.getWeight() + "kg)");
        } else {
            normalQueue.add(pkg);
            System.out.println("[KUYRUK] Normal kuyruğuna eklendi: " + pkg.getId());
        }
    }

    // Sıradaki paketi işle: VIP önce, sonra normal
    public Package processNext() {
        if (!priorityQueue.isEmpty()) {
            Package pkg = priorityQueue.poll();
            System.out.println("[İŞLEM] VIP paket işleniyor: " + pkg.getId());
            return pkg;
        }
        if (!normalQueue.isEmpty()) {
            Package pkg = normalQueue.poll();
            System.out.println("[İŞLEM] Normal paket işleniyor: " + pkg.getId());
            return pkg;
        }
        System.out.println("[KUYRUK] İşlenecek paket kalmadı.");
        return null;
    }

    public void printQueues() {
        System.out.println("--- VIP Kuyruk (" + priorityQueue.size() + " paket) ---");
        priorityQueue.forEach(p -> System.out.println("  " + p));
        System.out.println("--- Normal Kuyruk (" + normalQueue.size() + " paket) ---");
        normalQueue.forEach(p -> System.out.println("  " + p));
    }

    public Queue<Package>         getNormalQueue()   { return normalQueue; }
    public PriorityQueue<Package> getPriorityQueue() { return priorityQueue; }
    public int  normalQueueSize()   { return normalQueue.size(); }
    public int  priorityQueueSize() { return priorityQueue.size(); }
    public boolean isEmpty()        { return normalQueue.isEmpty() && priorityQueue.isEmpty(); }
}
