import java.util.ArrayList;
import java.util.List;

public class Box {
    private String boxId;
    private double maxVolume;    // Kutunun maksimum hacmi (litre)
    private double maxWeight;    // Kutunun maksimum ağırlığı (kg)
    private double usedVolume;
    private double usedWeight;
    private List<Package> packages;

    public Box(String boxId, double maxVolume, double maxWeight) {
        this.boxId = boxId;
        this.maxVolume = maxVolume;
        this.maxWeight = maxWeight;
        this.usedVolume = 0;
        this.usedWeight = 0;
        this.packages = new ArrayList<>();
    }

    // Paketi kutuya ekle
    public boolean addPackage(Package pkg) {
        if (canFit(pkg)) {
            packages.add(pkg);
            usedVolume += pkg.getVolume();
            usedWeight += pkg.getWeight();
            return true;
        }
        return false;
    }

    // Paket kutuya sığar mı?
    public boolean canFit(Package pkg) {
        return (usedVolume + pkg.getVolume() <= maxVolume) &&
               (usedWeight + pkg.getWeight() <= maxWeight);
    }

    // Kalan boş hacim
    public double getRemainingVolume() { return maxVolume - usedVolume; }

    // Kalan boş ağırlık kapasitesi
    public double getRemainingWeight() { return maxWeight - usedWeight; }

    public String getBoxId()           { return boxId; }
    public double getMaxVolume()       { return maxVolume; }
    public double getMaxWeight()       { return maxWeight; }
    public double getUsedVolume()      { return usedVolume; }
    public double getUsedWeight()      { return usedWeight; }
    public List<Package> getPackages() { return packages; }

    @Override
    public String toString() {
        return "Kutu[" + boxId + "] " +
               "Hacim: " + usedVolume + "/" + maxVolume + "L | " +
               "Ağırlık: " + usedWeight + "/" + maxWeight + "kg | " +
               "İçindeki paket sayısı: " + packages.size();
    }
}
