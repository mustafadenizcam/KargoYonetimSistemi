import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Main extends JFrame {

    // Arka plan sistemleri
    private static PackageHashTable hashTable = new PackageHashTable();
    private static CargoQueueSystem queueSystem = new CargoQueueSystem();
    private static CityGraph graph = new CityGraph();
    private static DijkstraAlgorithm dijkstra;
    private static PackingAlgorithm packer = new PackingAlgorithm(25.0, 15.0);
    private static List<Package> allPackagesForPacking = new ArrayList<>();

    // Tablo modeli (Paketler için)
    private DefaultTableModel tableModel;

    public Main() {
        sistemeVeriYukle();

        setTitle("Kargo Yönetim Sistemi");
        setSize(950, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        tabbedPane.addTab("Paket İşlemleri", createPaketTab());
        tabbedPane.addTab("Kuyruk Yönetimi", createKuyrukTab());
        tabbedPane.addTab("Rota Hesaplama", createRotaTab());
        tabbedPane.addTab("Paketleme Optimizasyonu", createPaketlemeTab());

        add(tabbedPane);
    }

    // --- SEKME 1: PAKET EKLEME VE SORGULAMA ---
    private JPanel createPaketTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setPreferredSize(new Dimension(320, 0));

        // Ekleme Formu
        JPanel formPanel = new JPanel(new GridLayout(7, 2, 5, 10));
        formPanel.setBorder(BorderFactory.createTitledBorder("Yeni Kargo Girişi"));

        JTextField txtId = new JTextField();
        JTextField txtGonderici = new JTextField();
        JTextField txtAlici = new JTextField();
        JTextField txtAgirlik = new JTextField();
        JTextField txtHacim = new JTextField();
        JCheckBox chkVip = new JCheckBox("VIP Kargo");

        formPanel.add(new JLabel("Paket ID:")); formPanel.add(txtId);
        formPanel.add(new JLabel("Gönderici:")); formPanel.add(txtGonderici);
        formPanel.add(new JLabel("Alıcı:")); formPanel.add(txtAlici);
        formPanel.add(new JLabel("Ağırlık (kg):")); formPanel.add(txtAgirlik);
        formPanel.add(new JLabel("Hacim (Litre):")); formPanel.add(txtHacim);
        formPanel.add(new JLabel("Durum:")); formPanel.add(chkVip);

        JButton btnEkle = new JButton("Sisteme Ekle");
        formPanel.add(new JLabel("")); formPanel.add(btnEkle);

        // Sorgulama Alanı
        JPanel aramaPanel = new JPanel(new BorderLayout(5, 5));
        aramaPanel.setBorder(BorderFactory.createTitledBorder("Paket Sorgulama"));
        JTextField txtArama = new JTextField();
        JButton btnAra = new JButton("Sorgula");

        aramaPanel.add(new JLabel("Paket ID: "), BorderLayout.WEST);
        aramaPanel.add(txtArama, BorderLayout.CENTER);
        aramaPanel.add(btnAra, BorderLayout.EAST);

        JPanel leftTopContainer = new JPanel(new BorderLayout(0, 15));
        leftTopContainer.add(formPanel, BorderLayout.NORTH);
        leftTopContainer.add(aramaPanel, BorderLayout.CENTER);
        leftPanel.add(leftTopContainer, BorderLayout.NORTH);

        // Tablo
        String[] columns = {"ID", "Gönderici", "Alıcı", "Ağırlık (kg)", "Hacim (L)", "VIP", "Durum"};
        tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);
        table.setRowHeight(22);

        for (Package p : allPackagesForPacking) {
            tabloyaEkle(p);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Kayıtlı Paketler"));

        btnEkle.addActionListener(e -> {
            try {
                Package pkg = new Package(txtId.getText(), txtGonderici.getText(), txtAlici.getText(),
                        Double.parseDouble(txtAgirlik.getText()), Double.parseDouble(txtHacim.getText()),
                        chkVip.isSelected());

                hashTable.addPackage(pkg);
                queueSystem.enqueue(pkg);
                allPackagesForPacking.add(pkg);
                tabloyaEkle(pkg);

                txtId.setText(""); txtGonderici.setText(""); txtAlici.setText("");
                txtAgirlik.setText(""); txtHacim.setText(""); chkVip.setSelected(false);

                JOptionPane.showMessageDialog(this, "Paket başarıyla sisteme eklendi.", "Bilgi", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Ağırlık ve hacim alanlarına sadece sayı giriniz.", "Giriş Hatası", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnAra.addActionListener(e -> {
            String aranan = txtArama.getText().trim();
            if (aranan.isEmpty()) return;

            Package found = hashTable.searchById(aranan);
            if (found != null) {
                String mesaj = "Paket Durumu: " + found.getStatus() + "\n" +
                        "Gönderen: " + found.getSenderName() + "\n" +
                        "Alıcı: " + found.getReceiverName() + "\n" +
                        "Ağırlık: " + found.getWeight() + " kg\n" +
                        "Hacim: " + found.getVolume() + " L";
                JOptionPane.showMessageDialog(this, mesaj, "Arama Sonucu", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Sistemde " + aranan + " ID'li bir paket bulunamadı.", "Bulunamadı", JOptionPane.WARNING_MESSAGE);
            }
        });

        panel.add(leftPanel, BorderLayout.WEST);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private void tabloyaEkle(Package p) {
        tableModel.addRow(new Object[]{
                p.getId(), p.getSenderName(), p.getReceiverName(),
                p.getWeight(), p.getVolume(),
                (p.isPriority() ? "Evet" : "Hayır"), p.getStatus()
        });
    }

    // --- SEKME 2: KUYRUK ---
    private JPanel createKuyrukTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnIsle = new JButton("Sıradaki Paketi İşle");
        btnIsle.setPreferredSize(new Dimension(0, 40));

        JTextArea txtLog = new JTextArea();
        txtLog.setEditable(false);
        JScrollPane scrollLog = new JScrollPane(txtLog);
        scrollLog.setBorder(BorderFactory.createTitledBorder("İşlem Geçmişi"));

        btnIsle.addActionListener(e -> {
            if (queueSystem.isEmpty()) {
                txtLog.append("İşlenecek paket kalmadı.\n");
            } else {
                Package p = queueSystem.processNext();
                if (p != null) {
                    p.setStatus("Yolda");
                    txtLog.append("İşlendi: " + p.getId() + " - " + (p.isPriority() ? "VIP" : "Normal") + "\n");

                    for (int i = 0; i < tableModel.getRowCount(); i++) {
                        if (tableModel.getValueAt(i, 0).equals(p.getId())) {
                            tableModel.setValueAt("Yolda", i, 6);
                            break;
                        }
                    }
                }
            }
        });

        panel.add(btnIsle, BorderLayout.NORTH);
        panel.add(scrollLog, BorderLayout.CENTER);

        return panel;
    }

    // --- SEKME 3: ROTA (YENİLENMİŞ - TABLOLU) ---
    private JPanel createRotaTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Sol Kısım: Şehirler Tablosu
        String[] columns = {"Şehir Kodu", "Şehir Adı"};
        DefaultTableModel cityTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; } // Tabloya elle yazı yazmayı engeller
        };
        JTable cityTable = new JTable(cityTableModel);
        cityTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // Sadece tek satır seçilsin
        cityTable.setRowHeight(22);

        JScrollPane scrollCity = new JScrollPane(cityTable);
        scrollCity.setBorder(BorderFactory.createTitledBorder("Şehir Listesi (Tablodan Seçiniz)"));
        scrollCity.setPreferredSize(new Dimension(250, 0));

        // Şehir verilerini tabloya doldur
        for (City c : graph.getAllCities()) {
            cityTableModel.addRow(new Object[]{c.getCityId(), c.getCityName()});
        }

        // Sağ Kısım: Seçim Butonları ve Sonuç Ekranı
        JPanel rightPanel = new JPanel(new BorderLayout(10, 10));

        JPanel selectionPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        selectionPanel.setBorder(BorderFactory.createTitledBorder("Rota Belirleme"));

        // Çıkış Şehri Paneli
        JPanel pnlKaynak = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnSetKaynak = new JButton("Çıkış Şehri Yap");
        JTextField txtKaynak = new JTextField(15);
        txtKaynak.setEditable(false); // Kullanıcı elle yazamasın
        pnlKaynak.add(btnSetKaynak);
        pnlKaynak.add(new JLabel(" Seçilen: "));
        pnlKaynak.add(txtKaynak);

        // Varış Şehri Paneli
        JPanel pnlHedef = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnSetHedef = new JButton("Varış Şehri Yap");
        JTextField txtHedef = new JTextField(15);
        txtHedef.setEditable(false); // Kullanıcı elle yazamasın
        pnlHedef.add(btnSetHedef);
        pnlHedef.add(new JLabel(" Seçilen: "));
        pnlHedef.add(txtHedef);

        // Hesaplama Butonları
        JPanel pnlHesapla = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnMesafe = new JButton("Mesafe Odaklı Hesapla");
        JButton btnMaliyet = new JButton("Maliyet Odaklı Hesapla");
        pnlHesapla.add(btnMesafe);
        pnlHesapla.add(btnMaliyet);

        selectionPanel.add(pnlKaynak);
        selectionPanel.add(pnlHedef);
        selectionPanel.add(pnlHesapla);

        // Sonuç Ekranı
        JTextArea txtSonuc = new JTextArea();
        txtSonuc.setEditable(false);
        JScrollPane scrollResult = new JScrollPane(txtSonuc);
        scrollResult.setBorder(BorderFactory.createTitledBorder("Hesaplama Sonucu"));

        rightPanel.add(selectionPanel, BorderLayout.NORTH);
        rightPanel.add(scrollResult, BorderLayout.CENTER);

        panel.add(scrollCity, BorderLayout.WEST);
        panel.add(rightPanel, BorderLayout.CENTER);

        // Seçim Aksiyonları
        btnSetKaynak.addActionListener(e -> {
            int selectedRow = cityTable.getSelectedRow();
            if (selectedRow != -1) {
                txtKaynak.setText((String) cityTableModel.getValueAt(selectedRow, 0));
            } else {
                JOptionPane.showMessageDialog(panel, "Lütfen sol taraftaki tablodan bir şehir seçin.");
            }
        });

        btnSetHedef.addActionListener(e -> {
            int selectedRow = cityTable.getSelectedRow();
            if (selectedRow != -1) {
                txtHedef.setText((String) cityTableModel.getValueAt(selectedRow, 0));
            } else {
                JOptionPane.showMessageDialog(panel, "Lütfen sol taraftaki tablodan bir şehir seçin.");
            }
        });

        // Hesaplama Aksiyonu
        java.awt.event.ActionListener aramaDinleyici = e -> {
            String src = txtKaynak.getText().trim();
            String dest = txtHedef.getText().trim();

            if (src.isEmpty() || dest.isEmpty()) {
                txtSonuc.setText("Lütfen çıkış ve varış şehirlerini tablodan seçip butonlara tıklayınız.");
                return;
            }

            boolean isMesafe = e.getSource() == btnMesafe;
            DijkstraAlgorithm.Mode mode = isMesafe ? DijkstraAlgorithm.Mode.DISTANCE : DijkstraAlgorithm.Mode.COST;

            DijkstraAlgorithm.RouteResult sonuc = dijkstra.findShortestPath(src, dest, mode);

            txtSonuc.setText("");
            if (sonuc.found) {
                txtSonuc.append(isMesafe ? "--- MESAFE OPTİMİZASYONU ---\n\n" : "--- MALİYET OPTİMİZASYONU ---\n\n");
                txtSonuc.append("Güzergah: " + String.join(" -> ", sonuc.path) + "\n");
                if (isMesafe) {
                    txtSonuc.append("Toplam Mesafe: " + sonuc.totalDistance + " km\n");
                } else {
                    txtSonuc.append("Toplam Maliyet: " + sonuc.totalCost + " TL\n");
                }
            } else {
                txtSonuc.append("Geçersiz rota. İki şehir arasında bağlantı bulunamadı.");
            }
        };

        btnMesafe.addActionListener(aramaDinleyici);
        btnMaliyet.addActionListener(aramaDinleyici);

        return panel;
    }

    // --- SEKME 4: PAKETLEME ---
    private JPanel createPaketlemeTab() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JButton btnPaketle = new JButton("Paketleri Kutulara Yerleştir (Algoritmayı Çalıştır)");
        btnPaketle.setPreferredSize(new Dimension(0, 40));

        JTextArea txtSonuc = new JTextArea();
        txtSonuc.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(txtSonuc);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Algoritma Sonucu"));

        btnPaketle.addActionListener(e -> {
            if (allPackagesForPacking.isEmpty()) {
                txtSonuc.setText("Sistemde paket bulunmuyor.");
                return;
            }
            PackingAlgorithm.PackingResult sonuc = packer.firstFitDecreasing(new ArrayList<>(allPackagesForPacking));

            txtSonuc.setText("Paketleme işlemi tamamlandı.\n");
            txtSonuc.append("Kullanılan Toplam Kutu Sayısı: " + sonuc.boxes.size() + "\n\n");

            for (Box box : sonuc.boxes) {
                txtSonuc.append("Kutu ID: " + box.getBoxId() + "\n");
                txtSonuc.append(String.format("Kullanılan Hacim: %.1f / %.1f Litre\n", box.getUsedVolume(), box.getMaxVolume()));
                txtSonuc.append(String.format("Kullanılan Ağırlık: %.1f / %.1f kg\n", box.getUsedWeight(), box.getMaxWeight()));
                txtSonuc.append("İçindeki Paketler:\n");
                for (Package pkg : box.getPackages()) {
                    txtSonuc.append(" - " + pkg.getId() + "\n");
                }
                txtSonuc.append("-----------------------------\n");
            }
        });

        panel.add(btnPaketle, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    // --- VERİ YÜKLEME ---
    private static void sistemeVeriYukle() {
        DataLoader.loadCities(graph);
        DataLoader.loadPackages(hashTable, queueSystem, allPackagesForPacking);

        if (graph.containsCity("IST")) {
            graph.addRoute("IST", "ANK", 450, 850);
            graph.addRoute("IST", "BUR", 150, 280);
            graph.addRoute("IST", "IZM", 480, 920);
            graph.addRoute("ANK", "IZM", 590, 1100);
            graph.addRoute("IZM", "ANT", 430, 810);
        }
        dijkstra = new DijkstraAlgorithm(graph);
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {}

        SwingUtilities.invokeLater(() -> {
            Main gui = new Main();
            gui.setVisible(true);
        });
    }
}