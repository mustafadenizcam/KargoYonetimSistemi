public class Package {
    private String id;
    private String senderName;
    private String receiverName;
    private double weight;   // kg
    private double volume;   // litre (en x boy x yükseklik)
    private boolean isPriority; // VIP/öncelikli mi?
    private String status;   // "Bekliyor", "Yolda", "Teslim Edildi"

    public Package(String id, String senderName, String receiverName,
                   double weight, double volume, boolean isPriority) {
        this.id = id;
        this.senderName = senderName;
        this.receiverName = receiverName;
        this.weight = weight;
        this.volume = volume;
        this.isPriority = isPriority;
        this.status = "Bekliyor";
    }

    // Getter ve Setter metotları
    public String getId()              { return id; }
    public String getSenderName()      { return senderName; }
    public String getReceiverName()    { return receiverName; }
    public double getWeight()          { return weight; }
    public double getVolume()          { return volume; }
    public boolean isPriority()        { return isPriority; }
    public String getStatus()          { return status; }
    public void setStatus(String s)    { this.status = s; }

    @Override
    public String toString() {
        return "[" + id + "] " + senderName + " -> " + receiverName +
               " | Ağırlık: " + weight + "kg | Hacim: " + volume + "L" +
               " | Öncelik: " + (isPriority ? "VIP" : "Normal") +
               " | Durum: " + status;
    }
}
