import java.util.*;

/*
 * KİŞİ 2 - Graf Veri Yapısı
 * Şehirler arası rota ağını temsil eder.
 * Ağırlıklı, çift yönlü (undirected) Adjacency List (Komşuluk Listesi) kullanır.
 * Kişi 1'in City sınıfıyla doğrudan uyumludur.
 */
public class CityGraph {

    // ── İç sınıf: Kenar (iki şehir arası rota) ──────────────────────────────
    public static class Edge {
        public final City destination;
        public final double distance; // km
        public final double cost;     // TL

        public Edge(City destination, double distance, double cost) {
            this.destination = destination;
            this.distance = distance;
            this.cost = cost;
        }

        @Override
        public String toString() {
            return String.format("[%s | %.0fkm | %.0f₺]",
                    destination.getCityName(), distance, cost);
        }
    }

    // cityId -> City nesnesi
    private final Map<String, City> cities;
    // cityId -> komşu kenar listesi
    private final Map<String, List<Edge>> adjacencyList;

    public CityGraph() {
        this.cities = new LinkedHashMap<>();
        this.adjacencyList = new LinkedHashMap<>();
    }

    // ── Şehir ekle ───────────────────────────────────────────────────────────
    public void addCity(City city) {
        cities.put(city.getCityId(), city);
        adjacencyList.putIfAbsent(city.getCityId(), new ArrayList<>());
    }

    // ── Çift yönlü rota ekle ─────────────────────────────────────────────────
    public void addRoute(String cityIdA, String cityIdB, double distance, double cost) {
        City a = cities.get(cityIdA);
        City b = cities.get(cityIdB);
        if (a == null || b == null) {
            System.out.println("[HATA] Şehir bulunamadı: " + cityIdA + " veya " + cityIdB);
            return;
        }
        adjacencyList.get(cityIdA).add(new Edge(b, distance, cost));
        adjacencyList.get(cityIdB).add(new Edge(a, distance, cost));
    }

    // ── Komşuları getir ──────────────────────────────────────────────────────
    public List<Edge> getNeighbors(String cityId) {
        return adjacencyList.getOrDefault(cityId, Collections.emptyList());
    }

    public City getCity(String cityId)          { return cities.get(cityId); }
    public Collection<City> getAllCities()       { return cities.values(); }
    public boolean containsCity(String cityId)  { return cities.containsKey(cityId); }

    // ── Grafı yazdır ─────────────────────────────────────────────────────────
    public void printGraph() {
        System.out.println("\n--- Şehir Rota Ağı (Graf) ---");
        for (Map.Entry<String, List<Edge>> entry : adjacencyList.entrySet()) {
            City city = cities.get(entry.getKey());
            System.out.print(city.getCityName() + " -> ");
            for (Edge e : entry.getValue()) {
                System.out.print(e + "  ");
            }
            System.out.println();
        }
    }
}
