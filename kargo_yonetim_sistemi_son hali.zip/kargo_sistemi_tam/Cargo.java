import java.util.ArrayList;
import java.util.List;

public class Cargo {
    private String cargoId;
    private City fromCity;
    private City toCity;
    private List<Box> boxes;
    private String status; 

    public Cargo(String cargoId, City fromCity, City toCity) {
        this.cargoId = cargoId;
        this.fromCity = fromCity;
        this.toCity = toCity;
        this.boxes = new ArrayList<>();
        this.status = "Hazırlanıyor";
    }

    public void addBox(Box box) {
        boxes.add(box);
    }

    // Bu kargodaki toplam paket sayısı hesaplanır.
    public int getTotalPackageCount() {
        int count = 0;
        for (Box box : boxes) {
            count += box.getPackages().size();
        }
        return count;
    }

    public String getCargoId()   { return cargoId; }
    public City getFromCity()    { return fromCity; }
    public City getToCity()      { return toCity; }
    public List<Box> getBoxes()  { return boxes; }
    public String getStatus()    { return status; }
    public void setStatus(String s) { this.status = s; }

    @Override
    public String toString() {
        return "Kargo[" + cargoId + "] " +
               fromCity.getCityName() + " -> " + toCity.getCityName() +
               " | Kutu: " + boxes.size() +
               " | Toplam Paket: " + getTotalPackageCount() +
               " | Durum: " + status;
    }
}
