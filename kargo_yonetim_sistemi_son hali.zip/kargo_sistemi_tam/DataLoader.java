import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class DataLoader {

    // Şehirleri .txt dosyasından okuyup Graf'a ekler
    public static void loadCities(CityGraph graph) {
        try (BufferedReader br = new BufferedReader(new FileReader("sehirler.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(","); // Virgüllerden böl
                if (parts.length == 2) {
                    graph.addCity(new City(parts[0].trim(), parts[1].trim()));
                }
            }
            System.out.println("[SİSTEM] Şehirler dosyadan başarıyla yüklendi.");
        } catch (IOException e) {
            System.out.println("[HATA] sehirler.txt okunamadı. Dosya yolunu kontrol edin!");
        }
    }

    // Paketleri .txt dosyasından okuyup sistemin ilgili yerlerine dağıtır
    public static void loadPackages(PackageHashTable hashTable, CargoQueueSystem queueSystem, List<Package> packageList) {
        try (BufferedReader br = new BufferedReader(new FileReader("paketler.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 6) {
                    String id = parts[0].trim();
                    String sender = parts[1].trim();
                    String receiver = parts[2].trim();
                    double weight = Double.parseDouble(parts[3].trim());
                    double volume = Double.parseDouble(parts[4].trim());
                    boolean isPriority = Boolean.parseBoolean(parts[5].trim());

                    Package pkg = new Package(id, sender, receiver, weight, volume, isPriority);

                    // Paketi Hash Table'a, Kuyruğa ve Paketleme listesine ekle
                    hashTable.addPackage(pkg);
                    queueSystem.enqueue(pkg);
                    packageList.add(pkg);
                }
            }
            System.out.println("[SİSTEM] Paketler dosyadan başarıyla yüklendi.");
        } catch (IOException e) {
            System.out.println("[HATA] paketler.txt okunamadı. Dosya yolunu kontrol edin!");
        }
    }
}