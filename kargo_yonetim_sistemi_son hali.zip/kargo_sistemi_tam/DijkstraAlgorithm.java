import java.util.*;

/*
 * KİŞİ 2 - Dijkstra Algoritması
 * CityGraph üzerinde iki modda çalışır:
 *   DISTANCE → en kısa km rotası
 *   COST     → en ucuz TL rotası
 */
public class DijkstraAlgorithm {

    public enum Mode { DISTANCE, COST }

    // ── Sonuç nesnesi ────────────────────────────────────────────────────────
    public static class RouteResult {
        public final List<String> path;       // şehir adları sırasıyla
        public final double totalDistance;    // toplam km
        public final double totalCost;        // toplam TL
        public final boolean found;

        public RouteResult(List<String> path, double totalDistance,
                           double totalCost, boolean found) {
            this.path = path;
            this.totalDistance = totalDistance;
            this.totalCost = totalCost;
            this.found = found;
        }

        public void print() {
            if (!found) {
                System.out.println("  [!] Rota bulunamadı.");
                return;
            }
            System.out.println("  Rota    : " + String.join(" -> ", path));
            System.out.printf( "  Mesafe  : %.1f km%n", totalDistance);
            System.out.printf( "  Maliyet : %.2f ₺%n",  totalCost);
        }
    }

    private final CityGraph graph;

    public DijkstraAlgorithm(CityGraph graph) {
        this.graph = graph;
    }

    /*
     * Dijkstra algoritması.
     * @param sourceId  Başlangıç şehri (cityId, örn. "IST")
     * @param targetId  Hedef şehri    (cityId, örn. "ANK")
     * @param mode      DISTANCE veya COST
     */
    public RouteResult findShortestPath(String sourceId, String targetId, Mode mode) {
        if (!graph.containsCity(sourceId) || !graph.containsCity(targetId)) {
            System.out.println("[HATA] Kaynak veya hedef şehir bulunamadı!");
            return new RouteResult(Collections.emptyList(), 0, 0, false);
        }

        // En iyi değerler (başta sonsuz)
        Map<String, Double> dist = new HashMap<>();
        Map<String, Double> cost = new HashMap<>();
        Map<String, String> prev = new HashMap<>(); // geri izleme
        Set<String> visited      = new HashSet<>();

        for (City city : graph.getAllCities()) {
            dist.put(city.getCityId(), Double.MAX_VALUE);
            cost.put(city.getCityId(), Double.MAX_VALUE);
        }
        dist.put(sourceId, 0.0);
        cost.put(sourceId, 0.0);

        // Öncelik kuyruğu: [optimize edilen değer, cityId]
        PriorityQueue<Object[]> pq = new PriorityQueue<>(
                Comparator.comparingDouble(a -> (double) a[0]));
        pq.offer(new Object[]{0.0, sourceId});

        while (!pq.isEmpty()) {
            Object[] curr = pq.poll();
            double currVal    = (double) curr[0];
            String currId     = (String) curr[1];

            if (visited.contains(currId)) continue;
            visited.add(currId);

            if (currId.equals(targetId)) break;

            for (CityGraph.Edge edge : graph.getNeighbors(currId)) {
                String nbId = edge.destination.getCityId();
                if (visited.contains(nbId)) continue;

                double newDist = dist.get(currId) + edge.distance;
                double newCost = cost.get(currId) + edge.cost;
                double newVal  = (mode == Mode.DISTANCE) ? newDist : newCost;
                double bestVal = (mode == Mode.DISTANCE) ? dist.get(nbId) : cost.get(nbId);

                if (newVal < bestVal) {
                    dist.put(nbId, newDist);
                    cost.put(nbId, newCost);
                    prev.put(nbId, currId);
                    pq.offer(new Object[]{newVal, nbId});
                }
            }
        }

        if (dist.get(targetId) == Double.MAX_VALUE)
            return new RouteResult(Collections.emptyList(), 0, 0, false);

        // Geri izleme ile yolu oluştur
        List<String> path = new ArrayList<>();
        String step = targetId;
        while (step != null) {
            City city = graph.getCity(step);
            path.add(0, city.getCityName());
            step = prev.get(step);
        }

        return new RouteResult(path, dist.get(targetId), cost.get(targetId), true);
    }

    /*
     * Kaynak şehirden tüm şehirlere en kısa yolları hesaplar.
     * cityId -> RouteResult map'i döner.
     */
    public Map<String, RouteResult> findAllPaths(String sourceId, Mode mode) {
        Map<String, RouteResult> results = new LinkedHashMap<>();
        for (City city : graph.getAllCities()) {
            if (!city.getCityId().equals(sourceId)) {
                results.put(city.getCityId(),
                        findShortestPath(sourceId, city.getCityId(), mode));
            }
        }
        return results;
    }
}
