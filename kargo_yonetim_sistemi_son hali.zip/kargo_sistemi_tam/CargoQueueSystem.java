/*
 Normal kargolar için Queue (FIFO sırası),
 VIP/öncelikli kargolar için PriorityQueue.
 */
import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class CargoQueueSystem {

    // Normal kargo kuyruğu (FIFO - ilk gelen ilk işlenir)
    private Queue<Package> normalQueue;

    // VIP kargo kuyruğu (ağırlığa göre öncelik - daha ağır paket önce)
    private PriorityQueue<Package> priorityQueue;

    public CargoQueueSystem() {
        this.normalQueue = new LinkedList<>();

        // PriorityQueue: önce ağır paketler işlensin (azalan sıra)
        this.priorityQueue = new PriorityQueue<>(
            Comparator.comparingDouble(Package::getWeight).reversed()
        );
    }

    // Paketi uygun kuyruğa ekle
    public void enqueue(Package pkg) {
        if (pkg.isPriority()) {
            priorityQueue.add(pkg);
            System.out.println("VIP kuyruğuna eklendi: " + pkg.getId());
        } else {
            normalQueue.add(pkg);
            System.out.println("Normal kuyruğa eklendi: " + pkg.getId());
        }
    }

    // Sıradaki paketi işle (VIP önce, sonra normal)
    public Package processNext() {
        if (!priorityQueue.isEmpty()) {
            Package pkg = priorityQueue.poll();
            System.out.println("VIP paket işleniyor: " + pkg.getId());
            return pkg;
        } else if (!normalQueue.isEmpty()) {
            Package pkg = normalQueue.poll();
            System.out.println("Normal paket işleniyor: " + pkg.getId());
            return pkg;
        }
        System.out.println("İşlenecek paket yok.");
        return null;
    }

    // Kuyruk durumunu gösterir
    public void printQueues() {
        System.out.println("--- VIP Kuyruk (" + priorityQueue.size() + " paket) ---");
        for (Package p : priorityQueue) {
            System.out.println("  " + p);
        }
        System.out.println("--- Normal Kuyruk (" + normalQueue.size() + " paket) ---");
        for (Package p : normalQueue) {
            System.out.println("  " + p);
        }
    }

    public int normalQueueSize()   { return normalQueue.size(); }
    public int priorityQueueSize() { return priorityQueue.size(); }
    public boolean isEmpty()       { return normalQueue.isEmpty() && priorityQueue.isEmpty(); }
}
