import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/*
 * KİŞİ 2 - Paketleme Algoritmaları
 * Kişi 1'in Box ve Package sınıflarını olduğu gibi kullanır.
 *
 * ─────────────────────────────────────────────────────────────────
 *  First Fit (FF)  : Paketi sığdığı İLK kutuya koy.
 *  Best Fit  (BF)  : Paketi en AZ boş alan kalan uygun kutuya koy.
 *  First Fit Decreasing (FFD): Paketleri büyükten küçüğe sırala,
 *                              sonra First Fit uygula. En verimli.
 * ─────────────────────────────────────────────────────────────────
 */
public class PackingAlgorithm {

    private final double boxMaxVolume; // Her yeni kutunun hacmi (litre)
    private final double boxMaxWeight; // Her yeni kutunun ağırlığı (kg)
    private static int boxCounter = 1; // Kutu ID sayacı

    public PackingAlgorithm(double boxMaxVolume, double boxMaxWeight) {
        this.boxMaxVolume = boxMaxVolume;
        this.boxMaxWeight = boxMaxWeight;
    }

    // ── Yardımcı: yeni boş kutu oluştur ────────────────────────────────────
    private Box newBox() {
        return new Box("ABOX-" + (boxCounter++), boxMaxVolume, boxMaxWeight);
    }

    // ── Sonuç nesnesi ───────────────────────────────────────────────────────
    public static class PackingResult {
        public final String algorithmName;
        public final List<Box> boxes;
        public final int packageCount;

        public PackingResult(String algorithmName, List<Box> boxes, int packageCount) {
            this.algorithmName = algorithmName;
            this.boxes = boxes;
            this.packageCount = packageCount;
        }

        public double averageUtilizationVolume() {
            if (boxes.isEmpty()) return 0;
            double total = 0;
            for (Box b : boxes)
                total += (b.getUsedVolume() / b.getMaxVolume());
            return (total / boxes.size()) * 100;
        }

        public void print() {
            System.out.println("\n=== " + algorithmName + " SONUCU ===");
            System.out.println("  Toplam Paket   : " + packageCount);
            System.out.println("  Kullanılan Kutu: " + boxes.size());
            System.out.printf( "  Ort. Doluluk   : %.1f%%%n", averageUtilizationVolume());
            for (Box box : boxes) {
                System.out.println("  " + box);
                for (Package pkg : box.getPackages()) {
                    System.out.println("    └─ " + pkg);
                }
            }
        }
    }

    // ── FIRST FIT ───────────────────────────────────────────────────────────
    /*
     * Her paket için kutuları baştan sona tara.
     * Sığdığı ilk kutuya ekle; hiçbirine sığmazsa yeni kutu aç.
     * Zaman karmaşıklığı: O(n * k)  [n=paket, k=kutu]
     */
    public PackingResult firstFit(List<Package> packages) {
        List<Box> boxes = new ArrayList<>();

        for (Package pkg : packages) {
            boolean placed = false;
            for (Box box : boxes) {
                if (box.addPackage(pkg)) {
                    placed = true;
                    break;
                }
            }
            if (!placed) {
                Box newBox = newBox();
                if (newBox.addPackage(pkg)) {
                    boxes.add(newBox);
                } else {
                    System.out.printf("[UYARI] '%s' tek başına kutuya sığmıyor, atlanıyor.%n",
                            pkg.getId());
                }
            }
        }
        return new PackingResult("FIRST FIT", boxes, packages.size());
    }

    // ── BEST FIT ────────────────────────────────────────────────────────────
    /*
     * Her paket için paketi sığdırabilecek kutular içinden
     * kalan hacmi en küçük olanı seç (en iyi doluluk hedefi).
     * Zaman karmaşıklığı: O(n * k)
     */
    public PackingResult bestFit(List<Package> packages) {
        List<Box> boxes = new ArrayList<>();

        for (Package pkg : packages) {
            Box bestBox = null;
            double bestRemaining = Double.MAX_VALUE;

            for (Box box : boxes) {
                if (box.canFit(pkg) && box.getRemainingVolume() < bestRemaining) {
                    bestRemaining = box.getRemainingVolume();
                    bestBox = box;
                }
            }

            if (bestBox != null) {
                bestBox.addPackage(pkg);
            } else {
                Box newBox = newBox();
                if (newBox.addPackage(pkg)) {
                    boxes.add(newBox);
                } else {
                    System.out.printf("[UYARI] '%s' tek başına kutuya sığmıyor, atlanıyor.%n",
                            pkg.getId());
                }
            }
        }
        return new PackingResult("BEST FIT", boxes, packages.size());
    }

    // ── FIRST FIT DECREASING ────────────────────────────────────────────────
    /*
     * Paketleri hacme göre büyükten küçüğe sırala, sonra First Fit uygula.
     * Büyük paketler önce yerleştirilir → daha az kutu kullanılır.
     * Orijinal liste bozulmaz (kopya üzerinde çalışılır).
     */
    public PackingResult firstFitDecreasing(List<Package> packages) {
        List<Package> sorted = new ArrayList<>(packages);
        sorted.sort(Comparator.comparingDouble(Package::getVolume).reversed());

        List<Box> boxes = new ArrayList<>();
        for (Package pkg : sorted) {
            boolean placed = false;
            for (Box box : boxes) {
                if (box.addPackage(pkg)) { placed = true; break; }
            }
            if (!placed) {
                Box newBox = newBox();
                if (newBox.addPackage(pkg)) boxes.add(newBox);
                else System.out.printf("[UYARI] '%s' tek başına kutuya sığmıyor, atlanıyor.%n",
                        pkg.getId());
            }
        }
        return new PackingResult("FIRST FIT DECREASING (FFD)", boxes, packages.size());
    }

    // ── KARŞILAŞTIRMA TABLOSU ───────────────────────────────────────────────
    /*
     * Üç algoritmayı aynı paket listesiyle çalıştırıp sonuçları karşılaştırır.
     */
    public void compareAll(List<Package> packages) {
        System.out.println("\n╔══════════════════════════════════════════════╗");
        System.out.println("║       ALGORİTMA KARŞILAŞTIRMASI              ║");
        System.out.println("╚══════════════════════════════════════════════╝");
        System.out.printf("  Paket sayısı     : %d%n", packages.size());
        System.out.printf("  Kutu kapasitesi  : %.1fL / %.1fkg%n", boxMaxVolume, boxMaxWeight);

        PackingResult ff  = firstFit(new ArrayList<>(packages));
        PackingResult bf  = bestFit(new ArrayList<>(packages));
        PackingResult ffd = firstFitDecreasing(new ArrayList<>(packages));

        System.out.println("\n  Algoritma               | Kutu | Ort. Doluluk");
        System.out.println("  ─────────────────────────────────────────────");
        System.out.printf( "  %-23s |  %2d  |  %.1f%%%n",
                "First Fit", ff.boxes.size(), ff.averageUtilizationVolume());
        System.out.printf( "  %-23s |  %2d  |  %.1f%%%n",
                "Best Fit", bf.boxes.size(), bf.averageUtilizationVolume());
        System.out.printf( "  %-23s |  %2d  |  %.1f%%%n",
                "First Fit Decreasing", ffd.boxes.size(), ffd.averageUtilizationVolume());
        System.out.println();
    }
}
