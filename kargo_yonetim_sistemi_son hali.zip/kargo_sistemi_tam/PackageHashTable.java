/*
 Hash Table kullanarak paketleri ID'ye göre saklar ve arar.
 */
import java.util.HashMap;

public class PackageHashTable {
    private HashMap<String, Package> table;

    public PackageHashTable() {
        this.table = new HashMap<>();
    }

    // Paket ekle
    public void addPackage(Package pkg) {
        table.put(pkg.getId(), pkg);
        System.out.println("Paket eklendi: " + pkg.getId());
    }

    // ID ile paket ara (O(1) - anında erişim)
    public Package searchById(String id) {
        return table.get(id); // Bulunamazsa null döner
    }

    // Paket sil
    public boolean removePackage(String id) {
        if (table.containsKey(id)) {
            table.remove(id);
            System.out.println("Paket silindi: " + id);
            return true;
        }
        System.out.println("Paket bulunamadı: " + id);
        return false;
    }

    // Toplam paket sayısı
    public int size() {
        return table.size();
    }

    // Tüm paketleri listele
    public void printAll() {
        if (table.isEmpty()) {
            System.out.println("Sistemde paket yok.");
            return;
        }
        System.out.println("--- Tüm Paketler (" + size() + " adet) ---");
        for (Package pkg : table.values()) {
            System.out.println(pkg);
        }
    }
}
